=== Nsthka Addons===
Contributors: (FALLEN, ASPER DEIGNS)
Tags: elementor, Elementor widgets, widgets, date 
Requires at least: 5.2
Tested up to: 5.4
Stable tag: 4.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

ntshka addons is widgets for elementor.

== Description ==

Ntshka addons contains 7 widgets, those widgets help you to maximize the experience with elementor 


*   "fal7" 
*   "elementor, Elementor widgets, widgets" 
*   "Requires at least" is the lowest version that the plugin will work on
*   "Tested up to" 5.4


== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about the updates? =
updates are coming, new widgets and more and more good ideas.

== Screenshots ==

1. main logo of a plugin

== Changelog ==


== A brief Markdown Example ==

Ordered list:

1. Pricing widget
2. Headline widget
3. FAQ widget
4.Timeline 
5. Card 1
6. Card 2 
7. Date 



`<?php code(); // goes in backticks ?>`
